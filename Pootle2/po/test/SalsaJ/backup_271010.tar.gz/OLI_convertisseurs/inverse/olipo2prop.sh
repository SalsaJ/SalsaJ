#!/bin/bash
# oliprop2po.sh

for file in `ls ../*.po`
do
newname=`basename $file .po`
templatename=`basename $file .po`
echo $newname
#prop2po -i $file -o $newname.po -t ../templates/$templatename".pot"
po2prop -i $file -o $newname.properties -t ../$templatename.properties
done
